The program fulfills both basic requirements and has enhanced features.

